package com.example.eventsrus.Model;

import java.util.List;

public class WeatherForecastResult {
       public String cod ;
        public int message ;
        public int cnt ;
        public List<MyList> list ;
        public City city ;



}
