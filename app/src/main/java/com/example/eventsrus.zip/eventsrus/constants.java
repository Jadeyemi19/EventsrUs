package com.example.eventsrus;

public class constants {
    public static final String MAPVIEW_BUNDLE_KEY="MapViewBundlekey";


}
