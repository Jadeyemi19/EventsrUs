package com.example.eventsrus.Model;

public class Clouds {
    public int all;

    public Clouds() {

    }

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}
