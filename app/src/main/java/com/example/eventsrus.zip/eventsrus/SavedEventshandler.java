package com.example.eventsrus;

public interface SavedEventshandler {
    //public  LiveData<List<SavedEvents>> getSavedEvents(LiveData<List<SavedEvents>> response);
}
