package com.example.eventsrus;

public interface RecyclerViewInterface {
    void onitemClick(int Position);
}
