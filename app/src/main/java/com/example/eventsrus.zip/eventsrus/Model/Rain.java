package com.example.eventsrus.Model;

public class Rain {
}
